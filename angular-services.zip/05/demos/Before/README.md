# Angular Services

This is the official repository for my Pluralsight course titled *Angular Services*. 
There are separate branches named after the modules in the course that contain the code as it 
exists at the end of that module.

I will update this repo below with any problems or small issues reported between updates to the actual course.

Thanks for watching and good luck on your Angular projects!
